# Employee Hiring & Workforce History | Power BI

A Power BI portfolio project focused on exploring employee hiring information and workforce history through a business intelligence report.

## Project overview

This project presents employee and hiring-related information in a visual reporting format. It demonstrates how Power BI can be used to explore workforce records and communicate HR information.

## Analysis focus

- Employee hiring information and historical workforce records
- Visual exploration of workforce information
- Interactive report exploration using available filters and visuals
- Review of report pages, tables, relationships, and calculations in Power BI Desktop

> The specific KPIs and dimensions depend on the data model included in the PBIX file. Review the report and model before interpreting or presenting specific findings.

## Tools and techniques

- **Microsoft Power BI Desktop** — report development and visualization
- **Power Query** — data preparation, where used in the report
- **DAX** — measures and calculations, where implemented

## Repository contents

| File | Description |
|---|---|
| `Employee Hiring and History.pbix` | Editable Power BI Desktop report |

## Open the project

1. Download and extract this ZIP archive.
2. Install and open Microsoft Power BI Desktop.
3. Open `Employee Hiring and History.pbix`.
4. If Power BI reports a missing data source, reconnect the source or update its path.
5. Refresh the report after confirming the data connection.

## Portfolio highlights

This project can demonstrate:
- Translating employee and recruitment information into visual reporting
- Exploring historical workforce information
- Building and reviewing an interactive Power BI report
- Understanding report visuals, data tables, relationships, and calculations

## Notes

- The PBIX file is the main project deliverable.
- Data refresh may require the original source file or a valid replacement dataset.
- Confirm KPI definitions and report filters before presenting business findings.

---
**Project category:** Business Intelligence / HR & Recruitment Analytics  
**Primary tool:** Microsoft Power BI
